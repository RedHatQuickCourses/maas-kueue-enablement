const fs = require('fs');
const path = require('path');

// Configuration and File Content Definitions
const FILES = {
    js: {
        path: 'supplemental-ui/js/progress-tracker.js',
        content: `/* [Paste the full content of your progress-tracker.js here] */`
    },
    css: {
        path: 'supplemental-ui/css/progress-tracker.css',
        content: `/* [Paste the full content of your progress-tracker.css here] */`
    }
};

function setupDirectories() {
    ['supplemental-ui/js', 'supplemental-ui/css', 'supplemental-ui/partials'].forEach(dir => {
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
            console.log(`✅ Created directory: ${dir}`);
        }
    });
}

function injectToHandlebars(filePath, marker, injection) {
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, marker + '\n' + injection);
        console.log(`✅ Created new partial: ${filePath}`);
        return;
    }

    const content = fs.readFileSync(filePath, 'utf8');
    if (content.includes('progress-tracking-installed')) {
        console.log(`ℹ️  Skipping ${filePath}: Already installed.`);
    } else {
        fs.appendFileSync(filePath, '\n' + injection);
        console.log(`✅ Updated existing partial: ${filePath}`);
    }
}

// EXECUTION
console.log('🚀 Starting Visual Progress Tracker Installation...');
setupDirectories();

// Write Static Files
fs.writeFileSync(FILES.js.path, FILES.js.content);
fs.writeFileSync(FILES.css.path, FILES.css.content);



// Inject Loaders
injectToHandlebars(
    'supplemental-ui/partials/footer-scripts.hbs', 
    '{{!-- progress-tracking-installed: v1.0 --}}', 
    '<script src="{{{uiRootPath}}}/js/progress-tracker.js"></script>'
);

injectToHandlebars(
    'supplemental-ui/partials/head-styles.hbs', 
    '{{!-- progress-tracking-installed: v1.0 --}}', 
    '<link rel="stylesheet" href="{{{uiRootPath}}}/css/progress-tracker.css">'
);

function updatePlaybook() {
    const playbookPath = 'antora-playbook.yml';
    if (!fs.existsSync(playbookPath)) {
        console.warn('⚠️  antora-playbook.yml not found. Please configure ui.supplemental_files manually.');
        return;
    }

    let content = fs.readFileSync(playbookPath, 'utf8');
    let modified = false;

    // 1. Ensure supplemental_files is set
    if (!content.includes('supplemental_files:')) {
        // This regex finds 'ui:' and adds the supplemental_files line right under it
        content = content.replace(/ui:/, 'ui:\n    supplemental_files: ./supplemental-ui');
        modified = true;
        console.log('✅ Added supplemental_files to playbook.');
    }

    // 2. Alert user if site: url is missing (Required for GitHub Pages)
    if (!content.includes('url:') && content.includes('site:')) {
        console.warn('💡 Reminder: Ensure your site.url is set in the playbook for GitHub Pages compatibility.');
    }

    if (modified) {
        fs.writeFileSync(playbookPath, content);
    }
}

console.log('🎉 Installation Complete! Please rebuild your Antora site.');